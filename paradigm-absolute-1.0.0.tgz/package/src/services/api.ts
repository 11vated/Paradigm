import { useOpsLog } from '@/stores/opsLog';

/**
 * API Service - Frontend to Backend communication
 * Minimal implementation that works with minimal server
 */

const API_BASE = (typeof window !== 'undefined' && (window as any).VITE_API_URL) || '';

// Helper: make API request
async function apiRequest(endpoint: string, options: RequestInit = {}) {
  const method = ((options.method as string) || 'GET').toUpperCase();
  const url = `${API_BASE}${endpoint}`;
  const opId = useOpsLog.getState().start(method, endpoint);
  const t0 = Date.now();
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });
    if (!response.ok) {
      const errBody = await response.json().catch(() => ({ error: 'Request failed' }));
      useOpsLog.getState().finish(opId, { ms: Date.now() - t0, status: 'error', statusCode: response.status, error: (errBody as any).error });
      throw new Error((errBody as any).error || ('HTTP ' + response.status));
    }
    const json = await response.json();
    useOpsLog.getState().finish(opId, { ms: Date.now() - t0, status: 'ok', statusCode: response.status });
    return json;
  } catch (e: any) {
    useOpsLog.getState().finish(opId, { ms: Date.now() - t0, status: 'error', error: String((e && e.message) || e) });
    throw e;
  }
}

// ─── Seeds API ───────────────────────────────────────────────
export async function listSeeds(params?: { domain?: string; limit?: number }) {
  const query = new URLSearchParams();
  if (params?.domain) query.set('domain', params.domain);
  if (params?.limit) query.set('limit', params.limit.toString());

  const response = await apiRequest(`/api/seeds?${query}`);
  return response.seeds || [];
}

export async function getSeed(id: string) {
  const response = await apiRequest(`/api/seeds/${id}`);
  return response;
}

export async function createSeed(data: { phrase?: string; domain?: string; prompt?: string; name?: string }) {
  const response = await apiRequest('/api/seeds', {
    method: 'POST',
    body: JSON.stringify(data),
  });
  return response.seed || response;
}

export async function deleteSeed(id: string) {
  await apiRequest(`/api/seeds/${id}`, { method: 'DELETE' });
  return true;
}

// ─── Generation API ─────────────────────────────────────────
export async function generateSeed(prompt: string, domain: string = 'character') {
  const response = await apiRequest('/api/seeds/generate', {
    method: 'POST',
    body: JSON.stringify({ prompt, domain }),
  });
  return response.seed || response;
}

export async function growSeed(id: string, params: Record<string, any> = {}) {
  const data = await apiRequest(`/api/seeds/${id}/grow`, {
    method: 'POST',
    body: JSON.stringify(params),
  });
  const artifact = data.artifact || data;
  return {
    id: artifact.id || `artifact-${id}`,
    name: artifact.name || 'Artifact',
    domain: artifact.domain || artifact.type || 'unknown',
    type: artifact.type || artifact.domain || 'unknown',
    seed_hash: artifact.seed_hash,
    generation: artifact.generation || 1,
    visual: artifact.visual || {},
    stats: artifact.stats || {},
    artifact: artifact.artifact || {},
    filePath: artifact.artifact?.filePath || artifact.filePath,
    objPath: artifact.artifact?.objPath || artifact.objPath,
    gltfPath: artifact.artifact?.gltfPath || artifact.gltfPath,
    pngPath: artifact.artifact?.pngPath || artifact.pngPath,
    wavPath: artifact.artifact?.wavPath || artifact.wavPath,
    emergent_assets: artifact.emergent_assets || {
      mesh: artifact.visual?.mesh || null,
      textures: artifact.visual?.textures || {}
    },
    render_hints: artifact.render_hints || {}
  };
}

export async function mutateSeed(id: string, genes?: Record<string, any>) {
  const response = await apiRequest(`/api/seeds/${id}/mutate`, {
    method: 'POST',
    body: JSON.stringify({ genes }),
  });
  return response.seed || response;
}

export async function evolveSeed(id: string, config?: {
  populationSize?: number;
  generations?: number;
  mutationRate?: number;
}) {
  const response = await apiRequest(`/api/seeds/${id}/evolve`, {
    method: 'POST',
    body: JSON.stringify(config),
  });
  return response;
}

export async function breedSeeds(id1: string, id2: string) {
  const response = await apiRequest('/api/seeds/breed', {
    method: 'POST',
    body: JSON.stringify({ seed1: id1, seed2: id2 }),
  });
  return response.child || response;
}

export async function updateGene(id: string, geneName: string, value: unknown) {
  const response = await apiRequest(`/api/seeds/${id}/genes/${geneName}`, {
    method: 'PUT',
    body: JSON.stringify({ value }),
  });
  return response;
}

// ─── GSPL API ──────────────────────────────────────────────
export async function parseGSPL(code: string) {
  const response = await apiRequest('/api/gspl/parse', {
    method: 'POST',
    body: JSON.stringify({ code }),
  });
  return response;
}

export async function executeGSPL(program: string) {
  const response = await apiRequest('/api/gspl/execute', {
    method: 'POST',
    body: JSON.stringify({ program }),
  });
  return response;
}

// ─── Agent API ─────────────────────────────────────────────
export async function agentQuery(query: string) {
  const response = await apiRequest('/api/agent/query', {
    method: 'POST',
    body: JSON.stringify({ query }),
  });
  return response;
}

// ─── Auth API ──────────────────────────────────────────────
export async function register(email: string, password: string) {
  const response = await apiRequest('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
  return response;
}

export async function login(email: string, password: string) {
  const response = await apiRequest('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
  return response;
}

// ─── Keys & Signing ───────────────────────────────────────
export async function generateKeys() {
  const response = await apiRequest('/api/keys/generate', {
    method: 'POST',
  });
  return response;
}

export async function signSeed(id: string) {
  const response = await apiRequest(`/api/seeds/${id}/sign`, {
    method: 'POST',
  });
  return response;
}

export async function verifySeed(id: string) {
  const response = await apiRequest(`/api/seeds/${id}/verify`);
  return response;
}

// ─── NFT/Mint ─────────────────────────────────────────────
export async function mintSeed(id: string, options?: { price?: string; royalty?: number }) {
  const response = await apiRequest(`/api/seeds/${id}/mint`, {
    method: 'POST',
    body: JSON.stringify(options),
  });
  return response;
}

export async function getNftInfo(id: string) {
  const response = await apiRequest(`/api/seeds/${id}/nft`);
  return response;
}

export async function getSeedPortraitUrl(id: string) {
  return `${API_BASE}/api/seeds/${id}/portrait`;
}

// ─── Composition APIs ─────────────────────────────────
export async function composeSeed(sourceId: string, targetDomain: string) {
  const response = await apiRequest('/api/seeds/compose', {
    method: 'POST',
    body: JSON.stringify({ source: sourceId, targetDomain }),
  });
  return response;
}

export async function getCompositionGraph() {
  const response = await apiRequest('/api/composition/graph', {
    method: 'GET',
  });
  return response;
}

export async function getCompositionPath(from: string, to: string) {
  const response = await apiRequest(`/api/composition/path?from=${from}&to=${to}`, {
    method: 'GET',
  });
  return response;
}

export async function getSimilarSeeds(seedId: string, limit: number = 10) {
  const response = await apiRequest(`/api/seeds/${seedId}/similar?limit=${limit}`, {
    method: 'GET',
  });
  return response;
}

// ─── Library API (ported from orphaned api.tsx) ────────────
export async function getLibrary() {
  const response = await apiRequest('/api/library', { method: 'GET' });
  return response;
}

export async function importFromLibrary(seedHash: string) {
  const response = await apiRequest('/api/library/import', {
    method: 'POST',
    body: JSON.stringify({ seed_hash: seedHash }),
  });
  return response;
}

// ─── Intelligence API (ported from orphaned api.tsx) ───────
export async function generateEmbedding(id: string) {
  const response = await apiRequest(`/api/seeds/${id}/embed`, {
    method: 'POST',
  });
  return response;
}

// ─── Info API (ported from orphaned api.tsx) ──────────────
export async function getDomains() {
  const response = await apiRequest('/api/domains', { method: 'GET' });
  return response;
}

export async function getGeneTypes() {
  const response = await apiRequest('/api/gene-types', { method: 'GET' });
  return response;
}

export async function getStats() {
  const response = await apiRequest('/api/stats', { method: 'GET' });
  return response;
}

export async function getEngines() {
  const response = await apiRequest('/api/engines', { method: 'GET' });
  return response;
}

// ─── DAO API ─────────────────────────────────────────────────
export async function getDAOState() {
  return apiRequest('/api/v1/dao');
}

export async function getDAOProposals(status?: string) {
  const qs = status ? `?status=${status}` : '';
  return apiRequest(`/api/v1/dao/proposals${qs}`);
}

export async function proposeDAO(data: {
  title: string; description?: string; type: string; payload: any; stake?: number;
}) {
  return apiRequest('/api/v1/dao/propose', { method: 'POST', body: JSON.stringify(data) });
}

export async function voteDAO(proposalId: string, support: boolean, votingPower?: number) {
  return apiRequest(`/api/v1/dao/vote/${proposalId}`, {
    method: 'POST',
    body: JSON.stringify({ support, votingPower }),
  });
}

export async function executeDAO(proposalId: string) {
  return apiRequest(`/api/v1/dao/execute/${proposalId}`, { method: 'POST' });
}
